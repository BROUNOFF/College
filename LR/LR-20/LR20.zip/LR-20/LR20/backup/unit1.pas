unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type
  { TMain }

  TMain = class(TForm)
    Button1: TButton;
    Button10: TButton;
    Button12: TButton;
    Button13: TButton;
    ButtonFullClear: TButton;
    ButtonBack: TButton;
    Button16: TButton;
    Button17: TButton;
    Button18: TButton;
    Button19: TButton;
    Button2: TButton;
    Button20: TButton;
    Button21: TButton;
    Button22: TButton;
    Button23: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    Edit1: TEdit;
    procedure Button10Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure Button13Click(Sender: TObject);
    procedure ButtonFullClearClick(Sender: TObject);
    procedure ButtonBackClick(Sender: TObject);
    procedure Button16Click(Sender: TObject);
    procedure Button17Click(Sender: TObject);
    procedure Button18Click(Sender: TObject);
    procedure Button19Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button20Click(Sender: TObject);
    procedure Button21Click(Sender: TObject);
    procedure Button22Click(Sender: TObject);
    procedure Button23Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    procedure SetOperation(op: String);
  public
  end;

var
  Main: TMain;
  a, b, c: Real;
  znak: String;

implementation

{$R *.lfm}

procedure TMain.SetOperation(op: String);
begin
  if TryStrToFloat(Edit1.Text, a) then
  begin
    znak := op;
    Edit1.Text := '';
  end
  else
    ShowMessage('Введите корректное число перед операцией');
end;

procedure TMain.Button10Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '0'
  else
    Edit1.Text := Edit1.Text + '0';
end;

procedure TMain.Button12Click(Sender: TObject);
var
  s: String;
begin
  s := Edit1.Text;
  if (s <> '0') and (Length(s) > 0) then
  begin
    if s[1] = '-' then
      Delete(s, 1, 1)
    else
      s := '-' + s;
    Edit1.Text := s;
  end;
end;

procedure TMain.Button13Click(Sender: TObject);
begin
  Edit1.Clear;
  a := 0;
  b := 0;
  c := 0;
end;

procedure TMain.ButtonFullClearClick(Sender: TObject);
begin
  Edit1.Clear;
end;

procedure TMain.ButtonBackClick(Sender: TObject);
var
  str: String;
begin
  str := Edit1.Text;
  if str <> '' then
    Delete(str, Length(str), 1);
  if str = '' then str := '0';
  Edit1.Text := str;
end;

procedure TMain.Button16Click(Sender: TObject);
begin
  SetOperation('/');
end;

procedure TMain.Button17Click(Sender: TObject);
begin
  SetOperation('*');
end;

procedure TMain.Button18Click(Sender: TObject);
begin
  SetOperation('-');
end;

procedure TMain.Button19Click(Sender: TObject);
var
  x: Real;
begin
  if TryStrToFloat(Edit1.Text, x) then
    Edit1.Text := FloatToStr(Sqr(x))
  else
    ShowMessage('Неверное значение');
end;

procedure TMain.Button1Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '1'
  else
    Edit1.Text := Edit1.Text + '1';
end;

procedure TMain.Button20Click(Sender: TObject);
var
  x: Real;
begin
  if TryStrToFloat(Edit1.Text, x) then
  begin
    if x <> 0 then
      Edit1.Text := FloatToStr(1 / x)
    else
      ShowMessage('Деление на ноль невозможно');
  end
  else
    ShowMessage('Неверное значение');
end;

procedure TMain.Button21Click(Sender: TObject);
begin
  if not TryStrToFloat(Edit1.Text, b) then
  begin
    ShowMessage('Введите корректное число');
    Exit;
  end;

  case znak of
    '+': c := a + b;
    '-': c := a - b;
    '*': c := a * b;
    '/':
      if b <> 0 then
        c := a / b
      else
      begin
        ShowMessage('Деление на ноль невозможно');
        Exit;
      end;
  end;

  Edit1.Text := FloatToStr(c);
end;

procedure TMain.Button22Click(Sender: TObject);
begin
  SetOperation('+');
end;

procedure TMain.Button23Click(Sender: TObject);
begin
  if (Edit1.Text = '') or (Edit1.Text = '0') then
    Edit1.Text := '0,'
  else if Pos(',', Edit1.Text) = 0 then
    Edit1.Text := Edit1.Text + ',';
end;

procedure TMain.Button2Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '2'
  else
    Edit1.Text := Edit1.Text + '2';
end;

procedure TMain.Button3Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '3'
  else
    Edit1.Text := Edit1.Text + '3';
end;

procedure TMain.Button4Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '4'
  else
    Edit1.Text := Edit1.Text + '4';
end;

procedure TMain.Button5Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '5'
  else
    Edit1.Text := Edit1.Text + '5';
end;

procedure TMain.Button6Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '6'
  else
    Edit1.Text := Edit1.Text + '6';
end;

procedure TMain.Button7Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '7'
  else
    Edit1.Text := Edit1.Text + '7';
end;

procedure TMain.Button8Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '8'
  else
    Edit1.Text := Edit1.Text + '8';
end;

procedure TMain.Button9Click(Sender: TObject);
begin
  if Edit1.Text = '0' then
    Edit1.Text := '9'
  else
    Edit1.Text := Edit1.Text + '9';
end;

procedure TMain.Edit1Change(Sender: TObject);
begin
  // Не требуется
end;

procedure TMain.FormCreate(Sender: TObject);
begin
  Edit1.Text := '0';
  Edit1.ReadOnly := True;
  Edit1.MaxLength := 16; // Ограничение длины ввода
end;

end.

