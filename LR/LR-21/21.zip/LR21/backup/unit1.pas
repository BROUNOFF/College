unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, edit, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, Buttons,
  Grids;

type

  { TfMain }

  TfMain = class(TForm)
    Panel: TPanel;
    bAdd: TSpeedButton;
    bEdit: TSpeedButton;
    bDel: TSpeedButton;
    bSort: TSpeedButton;
    SG: TStringGrid;
    procedure bAddClick(Sender: TObject);
    procedure PanelClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private

  public

  end;
   type

  Contacts = record
    Name: string[100];
    Telephon: string[20];
    Note: string[30];

  end; //record

var
  fMain: TfMain;
  adres: string; //адрес, откуда запущена программа
implementation

{$R *.lfm}

{ TfMain }

procedure TfMain.FormCreate(Sender: TObject);
begin

end;

procedure TfMain.bAddClick(Sender: TObject);
begin
  //очищаем поля, если там что-то есть:
  Panel.eName.Text:= '';
  Panel.eTelephone.Text:= '';
  //устанавливаем ModalResult редактора в mrNone:
  Panel.ModalResult:= mrNone;
  //теперь выводим форму:
  Panel.ShowModal;
  //если пользователь ничего не ввел - выходим:
  if (Panel.eName.Text= '') or (Panel.eTelephone.Text= '') then exit;
  //если пользователь не нажал "Сохранить" - выходим:
  if Panel.ModalResult <> mrOk then exit;
  //иначе добавляем в сетку строку, и заполняем её:
  SG.RowCount:= SG.RowCount + 1;
  SG.Cells[0, SG.RowCount-1]:= Panel.eName.Text;
  SG.Cells[1, SG.RowCount-1]:= Panel.eTelephone.Text;
  SG.Cells[2, SG.RowCount-1]:= Panel.CBNote.Text;
end;

procedure TfMain.PanelClick(Sender: TObject);
begin

end;

end.

