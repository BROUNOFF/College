unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, FileUtil, edit, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, Buttons,
  Grids;

type

  { TfMain }

  TfMain = class(TForm)
    Panel: TPanel;
    bAdd: TSpeedButton;
    bEdit: TSpeedButton;
    bDel: TSpeedButton;
    bSort: TSpeedButton;
    SG: TStringGrid;
    procedure bAddClick(Sender: TObject);
    procedure bDelClick(Sender: TObject);
    procedure bEditClick(Sender: TObject);
    procedure bSortClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure PanelClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private

  public

  end;
   type

  Contacts = record
    Name: string[100];
    Telephon: string[20];
    Note: string[30];

  end; //record

var
  fMain: TfMain;
  adres: string; //адрес, откуда запущена программа
implementation

{$R *.lfm}

{ TfMain }

procedure TfMain.FormCreate(Sender: TObject);
var
  MyCont: Contacts;
  f: file of Contacts;
  i: integer;
begin
  // путь к Документам пользователя
  adres := GetUserDir + 'Documents' + PathDelim;
  ForceDirectories(adres); // гарантируем наличие папки

  SG.Cells[0, 0] := 'Имя';
  SG.Cells[1, 0] := 'Телефон';
  SG.Cells[2, 0] := 'Примечание';
  SG.ColWidths[0] := 365;
  SG.ColWidths[1] := 150;
  SG.ColWidths[2] := 150;

  if not FileExists(adres + 'telephones.dat') then exit;

  try
    AssignFile(f, adres + 'telephones.dat');
    Reset(f);
    while not Eof(f) do
    begin
      Read(f, MyCont);
      SG.RowCount := SG.RowCount + 1;
      SG.Cells[0, SG.RowCount - 1] := MyCont.Name;
      SG.Cells[1, SG.RowCount - 1] := MyCont.Telephon;
      SG.Cells[2, SG.RowCount - 1] := MyCont.Note;
    end;
  finally
    CloseFile(f);
  end;
end;

procedure TfMain.bAddClick(Sender: TObject);
begin
  //очищаем поля, если там что-то есть:
  fEdit.eName.Text:= '';
  fEdit.eTelephone.Text:= '';
  //устанавливаем ModalResult редактора в mrNone:
  fEdit.ModalResult:= mrNone;
  //теперь выводим форму:
  fEdit.ShowModal;
  //если пользователь ничего не ввел - выходим:
  if (fEdit.eName.Text= '') or (fEdit.eTelephone.Text= '') then exit;
  //если пользователь не нажал "Сохранить" - выходим:
  if fEdit.ModalResult <> mrOk then exit;
  //иначе добавляем в сетку строку, и заполняем её:
  SG.RowCount:= SG.RowCount + 1;
  SG.Cells[0, SG.RowCount-1]:= fEdit.eName.Text;
  SG.Cells[1, SG.RowCount-1]:= fEdit.eTelephone.Text;
  SG.Cells[2, SG.RowCount-1]:= fEdit.CBNote.Text;
end;

procedure TfMain.bDelClick(Sender: TObject);
begin
  //если данных нет - выходим:
  if SG.RowCount = 1 then exit;
  //иначе выводим запрос на подтверждение:
  if MessageDlg('Требуется подтверждение',
                'Вы действительно хотите удалить контакт "' +
                SG.Cells[0, SG.Row] + '"?',
      mtConfirmation, [mbYes, mbNo, mbIgnore], 0) = mrYes then
         SG.DeleteRow(SG.Row);
end;

procedure TfMain.bEditClick(Sender: TObject);
begin
  //если данных в сетке нет - просто выходим:
  if SG.RowCount = 1 then exit;
  //иначе записываем данные в форму редактора:
  fEdit.eName.Text:= SG.Cells[0, SG.Row];
  fEdit.eTelephone.Text:= SG.Cells[1, SG.Row];
  fEdit.CBNote.Text:= SG.Cells[2, SG.Row];
  //устанавливаем ModalResult редактора в mrNone:
  fEdit.ModalResult:= mrNone;
  //теперь выводим форму:
  fEdit.ShowModal;
  //сохраняем в сетку возможные изменения,
  //если пользователь нажал "Сохранить":
  if fEdit.ModalResult = mrOk then begin
    SG.Cells[0, SG.Row]:= fEdit.eName.Text;
    SG.Cells[1, SG.Row]:= fEdit.eTelephone.Text;
    SG.Cells[2, SG.Row]:= fEdit.CBNote.Text;
  end;
end;
procedure TfMain.bSortClick(Sender: TObject);
type
  TContactRow = record
    Name: String;
    Telephone: String;
    Note: String;
  end;
var
  ContactsList: array of TContactRow;
  Temp: TContactRow;
  i, j: Integer;
begin
  // Если в сетке только заголовок — выходим
  if SG.RowCount <= 2 then Exit;

  // Сохраняем все строки из сетки в массив
  SetLength(ContactsList, SG.RowCount - 1);
  for i := 1 to SG.RowCount - 1 do
  begin
    ContactsList[i - 1].Name := SG.Cells[0, i];
    ContactsList[i - 1].Telephone := SG.Cells[1, i];
    ContactsList[i - 1].Note := SG.Cells[2, i];
  end;

  // Сортировка пузырьком по имени
  for i := 0 to High(ContactsList) - 1 do
    for j := i + 1 to High(ContactsList) do
      if AnsiCompareText(ContactsList[i].Name, ContactsList[j].Name) > 0 then
      begin
        Temp := ContactsList[i];
        ContactsList[i] := ContactsList[j];
        ContactsList[j] := Temp;
      end;

  // Возвращаем отсортированные данные в сетку
  for i := 0 to High(ContactsList) do
  begin
    SG.Cells[0, i + 1] := ContactsList[i].Name;
    SG.Cells[1, i + 1] := ContactsList[i].Telephone;
    SG.Cells[2, i + 1] := ContactsList[i].Note;
  end;
end;


procedure TfMain.FormClose(Sender: TObject; var CloseAction: TCloseAction);
  var
  MyCont: Contacts; //для очередной записи
  f: file of Contacts; //файл данных
  i: integer; //счетчик цикла
begin
  ShowMessage('Контакты сохранены в: ' + adres + 'telephones.dat');
  //если строки данных пусты, просто выходим:
  if SG.RowCount = 1 then exit;
  //иначе открываем файл для записи:
  try
    AssignFile(f, adres + 'telephones.dat');
    Rewrite(f);
    //теперь цикл - от первой до последней записи сетки:
    for i:= 1 to SG.RowCount-1 do begin
      //получаем данные текущей записи:
      MyCont.Name:= SG.Cells[0, i];
      MyCont.Telephon:= SG.Cells[1, i];
      MyCont.Note:= SG.Cells[2, i];
      //записываем их:
      Write(f, MyCont);
    end;
  finally
    CloseFile(f);
  end;
end;


procedure TfMain.PanelClick(Sender: TObject);
begin

end;

end.

