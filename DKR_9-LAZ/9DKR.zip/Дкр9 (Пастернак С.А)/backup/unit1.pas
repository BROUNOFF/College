unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Grids,
  ExtCtrls, Unit2, Unit3;

type

  { TForm1 }

  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    ButtonAdd: TButton;
    ButtonEdit: TButton;
    ButtonLoad: TButton;
    ButtonSave: TButton;
    ButtonDelete: TButton;
    OpenDialog1: TOpenDialog;
    SaveDialog1: TSaveDialog;
    StringGrid1: TStringGrid;
    procedure Button1Click(Sender: TObject);
    procedure ButtonAddClick(Sender: TObject);
    procedure ButtonEditClick(Sender: TObject);
    procedure ButtonLoadClick(Sender: TObject);
    procedure ButtonSaveClick(Sender: TObject);
    procedure ButtonDeleteClick(Sender: TObject);
    procedure ComboBox2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    procedure LoadGridFromFile(const FileName: string);
    procedure SaveGridToFile(const FileName: string);
  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.FormCreate(Sender: TObject);
begin
  StringGrid1.ColCount := 6;
  StringGrid1.RowCount := 1;
  StringGrid1.FixedRows := 1;

  StringGrid1.Cells[0, 0] := 'Название';
  StringGrid1.Cells[1, 0] := 'Столица';
  StringGrid1.Cells[2, 0] := 'Население';
  StringGrid1.Cells[3, 0] := 'Существует?';
  StringGrid1.Cells[4, 0] := 'Форма правления';
  StringGrid1.Cells[5, 0] := 'Континент';
end;

procedure TForm1.ButtonAddClick(Sender: TObject);
begin
  Form2.Edit1.Text := '';
  Form2.Edit2.Text := '';
  Form2.Edit3.Text := '';
  Form2.ComboBox1.Text := '...';
  Form2.Edit4.Text := '';

  if Form2.ShowModal = mrOK then
  begin
    StringGrid1.RowCount := StringGrid1.RowCount + 1;
    with StringGrid1 do
    begin
      Cells[0, RowCount-1] := Form2.Edit1.Text;
      Cells[1, RowCount-1] := Form2.Edit2.Text;
      Cells[2, RowCount-1] := Form2.Edit3.Text;
      Cells[3, RowCount-1] := Form2.ComboBox1.Text;
      Cells[4, RowCount-1] := Form2.Edit4.Text;
      Cells[5, RowCount-1] := Form2.Combobox2.Text;
    end;
  end;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin

end;

procedure TForm1.ButtonEditClick(Sender: TObject);
begin
  if StringGrid1.Row < 1 then Exit;

  with StringGrid1 do
  begin
    Form2.Edit1.Text := Cells[0, Row];
    Form2.Edit2.Text := Cells[1, Row];
    Form2.Edit3.Text := Cells[2, Row];
    Form2.ComboBox1.Text := Cells[3, Row];
    Form2.Edit4.Text := Cells[4, Row];
    Form2.Combobox2.Text := Cells[5, Row];
  end;

  if Form2.ShowModal = mrOK then
  begin
    with StringGrid1 do
    begin
      Cells[0, Row] := Form2.Edit1.Text;
      Cells[1, Row] := Form2.Edit2.Text;
      Cells[2, Row] := Form2.Edit3.Text;
      Cells[3, Row] := Form2.ComboBox1.Text;
      Cells[4, Row] := Form2.Edit4.Text;
      Cells[5, Row] := Form2.Combobox2.Text;
    end;
  end;
end;

procedure TForm1.ButtonDeleteClick(Sender: TObject);
begin
  if StringGrid1.RowCount > 1 then
    StringGrid1.DeleteRow(StringGrid1.Row);
end;

procedure TForm1.ComboBox2Click(Sender: TObject);
begin

end;

procedure TForm1.ButtonLoadClick(Sender: TObject);
begin
  if OpenDialog1.Execute then
    LoadGridFromFile(OpenDialog1.FileName);
end;

procedure TForm1.ButtonSaveClick(Sender: TObject);
begin
  if SaveDialog1.Execute then
    SaveGridToFile(SaveDialog1.FileName);
end;

procedure TForm1.LoadGridFromFile(const FileName: string);
var
  SL: TStringList;
  i: Integer;
begin
  SL := TStringList.Create;
  try
    SL.LoadFromFile(FileName);
    StringGrid1.RowCount := 1;
    for i := 0 to SL.Count - 1 do
    begin
      StringGrid1.RowCount := StringGrid1.RowCount + 1;
      StringGrid1.Rows[i + 1].CommaText := SL[i];
    end;
  finally
    SL.Free;
  end;
end;

procedure TForm1.SaveGridToFile(const FileName: string);
var
  SL: TStringList;
  i: Integer;
begin
  SL := TStringList.Create;
  try
    for i := 1 to StringGrid1.RowCount - 1 do
      SL.Add(StringGrid1.Rows[i].CommaText);
    SL.SaveToFile(FileName);
    ShowMessage('Сохранено успешно!');
  finally
    SL.Free;
  end;
end;

end.
