unit Unit2;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  Unit3;

type

  { TForm2 }

  TForm2 = class(TForm)
    Button1: TButton;
    ComboBox1: TComboBox;  // Существует?
    ComboBox2: TComboBox;  // Континент
    Edit1: TEdit;          // Название
    Edit2: TEdit;          // Столица
    Edit3: TEdit;          // Население
    Edit4: TEdit;          // Форма правления
    Image1: TImage;
    Image2: TImage;
    Image3: TImage;
    Image4: TImage;
    Image5: TImage;
    Image6: TImage;
    Label1: TLabel;        // Название
    Label2: TLabel;        // Столица
    Label3: TLabel;        // Население
    Label4: TLabel;        // Существует?
    Label5: TLabel;        // Форма правления
    Label6: TLabel;        // Континент
    procedure Button1Click(Sender: TObject);
    procedure ComboBox1Change(Sender: TObject);
    procedure ComboBox2Change(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure Edit3Change(Sender: TObject);
    procedure Edit4Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Image1Click(Sender: TObject);
    procedure EditKeyPress_NoDigits(Sender: TObject; var Key: Char);
    procedure Edit3KeyPress(Sender: TObject; var Key: Char);
  private
    function IsValidContinent(const S: string): Boolean;
  public

  end;

var
  Form2: TForm2;

implementation

{$R *.lfm}

{ TForm2 }

procedure TForm2.FormCreate(Sender: TObject);
begin
  ComboBox1.Items.Text := 'Да'#13'Нет';
  ComboBox2.Items.Text :=
    'Европа'#13'Азия'#13'Африка'#13'Северная Америка'#13'Южная Америка'#13'Австралия'#13'Антарктида';
end;

procedure TForm2.Image1Click(Sender: TObject);
begin

end;

function TForm2.IsValidContinent(const S: string): Boolean;
begin
  Result := ComboBox2.Items.IndexOf(S) <> -1;
end;

procedure TForm2.Button1Click(Sender: TObject);
var
  Population: Integer;
begin
  if (Trim(Edit1.Text) = '') or (Trim(Edit2.Text) = '') or
     (Trim(Edit3.Text) = '') or (Trim(ComboBox1.Text) = '') or
     (Trim(Edit4.Text) = '') or (Trim(ComboBox2.Text) = '') then
  begin
    Form3.Label1.Caption := 'Заполните все поля!';
    Form3.ShowModal;
    Exit;
  end;

  if not TryStrToInt(Edit3.Text, Population) then
  begin
    Form3.Label1.Caption := 'Население должно быть числом!';
    Form3.ShowModal;
    Exit;
  end;

  if (Population <= 0) or (Population > 1500000000) then
  begin
    Form3.Label1.Caption := 'Население должно быть от 1 до 1 500 000 000.';
    Form3.ShowModal;
    Exit;
  end;

  if not IsValidContinent(ComboBox2.Text) then
  begin
    Form3.Label1.Caption := 'Введите корректный континент.';
    Form3.ShowModal;
    Exit;
  end;

  ModalResult := mrOK;
end;

procedure TForm2.ComboBox1Change(Sender: TObject);
begin

end;

procedure TForm2.ComboBox2Change(Sender: TObject);
begin

end;

procedure TForm2.Edit1Change(Sender: TObject);
begin

end;

procedure TForm2.Edit3Change(Sender: TObject);
begin

end;

procedure TForm2.Edit4Change(Sender: TObject);
begin

end;
      procedure TForm2.EditKeyPress_NoDigits(Sender: TObject; var Key: char);
begin
  if Key in ['0'..'9'] then
    Key := #0; // отменяет ввод цифры
end;
      procedure TForm2.Edit3KeyPress(Sender: TObject; var Key: Char);
begin
  if not (Key in ['0'..'9', '.', ' ', #8]) then
    Key := #0; // Отменяем ввод недопустимых символов
end;
end.
