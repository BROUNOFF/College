unit Unit3;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type

  { TForm3 }

  TForm3 = class(TForm)
    Button1: TButton;
    Label1: TLabel;
    procedure Button1Click(Sender: TObject);
  end;

var
  Form3: TForm3;

implementation

{$R *.lfm}

procedure TForm3.Button1Click(Sender: TObject);
begin
  Close;
end;

end.
