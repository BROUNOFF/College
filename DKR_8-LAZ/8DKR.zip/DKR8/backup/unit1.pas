unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons;

type

  { TMain }

  TMain = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Edit4: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Label1Click(Sender: TObject);
  private

  public

  end;

var
  Main: TMain;

implementation

{$R *.lfm}

{ TMain }

procedure TMain.Label1Click(Sender: TObject);
begin

end;

procedure TMain.Edit1Change(Sender: TObject);
begin

end;

procedure TMain.FormCreate(Sender: TObject);
begin

end;

procedure TMain.Button1Click(Sender: TObject);
begin
  ShowMessage(
    'Калькулятор рассчитывает прирост капитала двумя способами:'#13#13 +
    '1. Простые проценты — проценты начисляются только на первоначальную сумму.'#13 +
    'Формула: S + (S × P × N) + довложения.'#13#13 +
    '2. Сложные проценты — каждый месяц проценты начисляются на всю накопленную сумму.'#13 +
    'Формула: S × (1 + P)^N с учётом довложений каждый месяц.'#13#13 +
    'P — месячная процентная ставка (например, 2% → 0.02)'#13 +
    'D — ежемесячное довложение, добавляется перед начислением процентов.'
  );
end;

procedure TMain.Button2Click(Sender: TObject);
var
  S, P, D: Double;
  N, i: Integer;
  SimpleTotal, CompoundTotal: Double;
  SimpleResult, CompoundResult, Msg: String;
begin

  S := StrToFloat(Edit1.Text);
  P := StrToFloat(Edit2.Text) / 100;
  N := StrToInt(Edit3.Text);
  D := StrToFloat(Edit4.Text);

  SimpleTotal := S;
  CompoundTotal := S;
  SimpleResult := 'Простые проценты:'#13;
  CompoundResult := 'Сложные проценты:'#13;

  for i := 1 to N do
  begin
    SimpleTotal := SimpleTotal + (S * P) + D;
    SimpleResult := SimpleResult + Format('Месяц %d: %.2f'#13, [i, SimpleTotal]);

    CompoundTotal := (CompoundTotal + D) * (1 + P);
    CompoundResult := CompoundResult + Format('Месяц %d: %.2f'#13, [i, CompoundTotal]);
  end;

  Msg := SimpleResult + #13 + CompoundResult;
  ShowMessage(Msg);
end;

end.

